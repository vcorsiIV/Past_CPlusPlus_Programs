#pragma once

ref class Receiver
{
public:
	Receiver(void);
};
