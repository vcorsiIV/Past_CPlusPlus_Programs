#include <iostream>
#include <fstream>
using namespace std; 
#include <cstring> 
#include <cstdlib> 
 
char *entry, letter, choice[2]; 
int ascii, len, binary[8], binaryr[8], total; 
void prog(); 
 
int main() { 
      prog();      
      return 0; 
}         
 
void prog() { 
	entry = new char[101]; 
 
	cout<<"Enter string to convert (up to 100 chars): "; 
    cin.getline(entry, 100); 
	len = strlen(entry); 

//Converts the chars to bits('0' and '1' characters)
	for(int i = 0; i<len; i++) { 
		total = 0; 
		letter = entry[i]; 
		ascii = letter;
		
		while(ascii>0) { 
			if((ascii%2)==0) {
				binary[total] = 0; 
				ascii = ascii/2; 
				total++;
			} 
			
			else { 
				binary[total] = 1; 
				ascii = ascii/2; 
				total++; 
			}
		} 
		while(total>=0) {
			total--; 
		}

		//Method to order bits from least significant bit(LSB) to most significant bit(MSB).
		int k = 0;
		for (int i=7; i>=0; i--){
			binaryr[i] = binary[k];
			k++;
			cout<<binaryr[i];
		}
	}

	//Sends the bits to the transmitted_message file.
	cout<<endl<<"Write to file?(1 = yes and exits, 2= just exits)?: "; 
	cin.getline(choice,3);
	if(choice[0] == '1'){
		for (int i=0; i<=len; i++){
			ofstream file;
			file.open("transmitted_message.txt");
			file << binary[i];
			file.close();
		}
	}
	else 
		exit(0);
}