#pragma once

class Transmitter
{
public:
	Transmitter(void);
	~Transmitter(void);
};
